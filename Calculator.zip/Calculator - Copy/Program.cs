﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num01;
            int num02;

            Console.WriteLine("Welcome to Calculator! - By: Anthony Grieco");
            Redo:
            Console.WriteLine("1 for Addition, 2 for Subtraction, 3 for Mulitiplication, 4 for Division");
            int start = Convert.ToInt32(Console.ReadLine());
            
            if(start == 1)
            {
                Console.WriteLine("Addition:");
                Console.Write("Input a number: ");
                num01 = Convert.ToInt32( Console.ReadLine() );

                Console.Write("Input a number: ");
                num02 = Convert.ToInt32( Console.ReadLine() );

                int add = num01+num02;
                Console.WriteLine("The answer is "+add+".");
                goto Redo;
                }
            else if(start == 2)
            {
                Console.WriteLine("Subtraction:");
                Console.Write("Input a number: ");
                num01 = Convert.ToInt32( Console.ReadLine() );

                Console.Write("Input a number: ");
                num02 = Convert.ToInt32( Console.ReadLine() );

                int minus = num01-num02;
                Console.WriteLine("The answer is "+minus+".");
                goto Redo;
            }
            else if(start == 3)
            {
                Console.WriteLine("Multiplication:");
                Console.Write("Input a number: ");
                num01 = Convert.ToInt32( Console.ReadLine() );

                Console.Write("Input a number: ");
                num02 = Convert.ToInt32( Console.ReadLine() );

                int times = num01*num02;
                Console.WriteLine("The answer is "+times+".");
                goto Redo;
            }
            else if(start == 4)
            {
                Console.WriteLine("Division:");
                Console.Write("Input a number: ");
                num01 = Convert.ToInt32( Console.ReadLine() );

                Console.Write("Input another number: ");
                num02 = Convert.ToInt32( Console.ReadLine() );

                int divide = num01/num02;
                Console.WriteLine("The answer is "+divide+".");
                goto Redo;
            }

        }
    }
}